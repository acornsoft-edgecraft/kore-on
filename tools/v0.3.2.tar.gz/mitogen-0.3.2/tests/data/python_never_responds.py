#!/usr/bin/python
# I am a Python interpreter that sits idle until the connection times out.

import time

while True:
    time.sleep(86400)
