def f():
    """docstring
    """
    pass
