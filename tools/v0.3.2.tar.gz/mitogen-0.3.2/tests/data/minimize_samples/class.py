class C:
    """docstring
    """

    def method(self):
        """docstring
        """
        pass
