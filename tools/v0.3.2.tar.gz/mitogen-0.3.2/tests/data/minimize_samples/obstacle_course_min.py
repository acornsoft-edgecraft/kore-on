#!python
# coding : utf-8



import sys

"cc", {}

def f1(a, b= None, c=[]):


 x = ""
 print(
 a,

b,
 """arg1""",
"""arg2""",
 c )

 'foo' > sys.stderr


 sys.stdout;lambda: "justastring"

1j

def f2():


 pass
class c:




 f='justastring'


@f1
class c2(object):

 def __init__(self):

  def inner(): pass
  d = {'a':0}
  for x in '':

