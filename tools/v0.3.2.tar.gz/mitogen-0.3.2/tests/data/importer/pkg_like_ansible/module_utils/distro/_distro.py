I_AM = "the module that replaced the package"
