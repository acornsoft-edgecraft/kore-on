
import simple_pkg.b


def subtract_one_add_two(n):
    return simple_pkg.b.subtract_one(n) + 2
