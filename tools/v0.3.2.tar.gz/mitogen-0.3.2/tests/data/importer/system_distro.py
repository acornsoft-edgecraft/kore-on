# #590: a system module that replaces some subpackage
I_AM = "the system module that replaced the subpackage"
