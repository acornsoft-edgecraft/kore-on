
import sys


def say_hi():
    print('hi')
