from .regular_mod import say_hi
