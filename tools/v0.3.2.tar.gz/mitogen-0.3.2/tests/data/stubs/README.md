
# tests/data/stubs/

Dummy implementations of various third party tools that just spawn local Python
interpreters. Used to roughly test the tools' associated Mitogen classes.
