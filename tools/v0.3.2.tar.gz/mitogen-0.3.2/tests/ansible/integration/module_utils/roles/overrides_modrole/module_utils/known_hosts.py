# Override basic.py with our own thing.

def path():
    return 'ansible/integration/module_utils/roles/override_modrole/module_utils/basic.py'
